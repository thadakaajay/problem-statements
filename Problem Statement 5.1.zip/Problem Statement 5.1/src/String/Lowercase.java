package String;

public class Lowercase {
	public static void main(String[] args) {
		String str="JAVA is Simple";
		String strup=str.toLowerCase();
		System.out.println(strup);
	}
	

}
