package Program;

public class Removechar {
	 static void printRotatedString(String str)
	    {
	        int len = str.length();
	      
	 
	        StringBuffer stringbuffer;
	         
	        for (int i = 0; i < len; i++)
	        {
	            stringbuffer = new StringBuffer();
	             
	            int j = i; 
	            int k = 0;  
	      
	            
	            for (int k2 = j; k2 < str.length(); k2++) {
	                stringbuffer.insert(k, str.charAt(j));
	                k++;
	                j++;
	            }
	      
	          
	            j = 0;
	            while (j < i)
	            {
	                stringbuffer.insert(k, str.charAt(j));
	                j++;
	                k++;
	            }
	      
	            System.out.println(stringbuffer);
	        }
	    }
	     
	   
	    public static void main(String[] args)
	    {
	        String  str = new String("MPHASIS");
	        printRotatedString(str);
	    }
}
