package String;

public class CharAt {
public static void main(String[] args) {
	String s="JAVA is Simple";
	String[] w=s.split("");
	char ch=s.charAt(0);
	System.out.println(ch);
	
	
}
}
