package String;

public class wordcharreverse {


public static void main(String[] args) {
	String s="JAVA is Simple";
	String res="";
	for(int i=s.length()-1;i>0;i--) {
		res=res+s.charAt(i);
	}
	
	
    System.out.print(res);
}
}
	
	
	