package Student;

import java.util.ArrayList;
public class Student {
   public static void main(String[] args) {
      ArrayList<String> names = new ArrayList<String>();
      names.add("Jim");
      names.add("Jack");
      names.add("Ajeet");
      names.add("Chaitanya");
      
      
      if(names.contains("Jack")) {
    	  System.out.println("Jack is exists in the ArrayList");
      }
      else {
    	  System.out.println("Jack is does not exists in the ArrayList");
      }
   }
}
