package String;

public class Length {


 
public static void main(String args[]){  
String s1="JAVA is Simple";  
String[] w=s1.split(" ");

System.out.println("string length is: "+s1.length());//10 is the length of javatpoint string  
 
}
}  