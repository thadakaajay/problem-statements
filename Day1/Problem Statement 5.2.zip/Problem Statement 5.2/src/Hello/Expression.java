package Hello;

public class Expression {
	
		 public static void main(String args[])
		    {
		        String str = "23 + 45 - ( 343 / 12 )";
		        String[] s = str.split(" ", 9);
		 
		        for (String a : s)
		            System.out.println(a);
		    }
	}


