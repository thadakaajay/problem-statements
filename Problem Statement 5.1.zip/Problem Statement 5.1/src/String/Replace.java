package String;

public class Replace {
	public static void main(String[] args) {
		String str="JAVA is Simple";
		String strup=str.toUpperCase();
		System.out.println(strup);
	}

}
